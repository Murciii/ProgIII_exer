package ud.prog3.pro00.simulador;

import java.util.ArrayList;

public class Ecosistema {
	
	public static Ecosistema ecosistema = new Ecosistema (new ArrayList<ElementoEcosistema>());
	protected ArrayList<ElementoEcosistema> listaEEs;

	public Ecosistema(ArrayList<ElementoEcosistema> listaEEs) {
		// TODO Auto-generated constructor stub
		this.listaEEs = new ArrayList<ElementoEcosistema>();
	}
	
	public ArrayList<ElementoEcosistema> getElementos() {
		return listaEEs;
	}
	public void setListaEEs(ArrayList<ElementoEcosistema> listaEEs) {
		this.listaEEs = listaEEs;
	}	
	public static Ecosistema getMundo() {
		return ecosistema;
	}

	public static int distancia(ElementoEcosistema ee , ElementoEcosistema ee2) {
		double resultado;
		resultado = Math.sqrt( Math.pow((ee2.getPosicion().x - ee.getPosicion().x),2) +Math.pow((ee2.getPosicion().y - ee.getPosicion().y), 2)) ; 
		return (int) resultado;
	}
	
	
}
