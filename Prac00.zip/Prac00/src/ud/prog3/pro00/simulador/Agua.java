package ud.prog3.pro00.simulador;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Agua extends ElementoEcosistema{
	
	protected long cantidad =  (int) Math.sqrt(dimension.getWidth()*dimension.height);
	protected JPanel panelA;

	
	public Agua() {
		super();
	}
	
	
	public Agua(String titulo, Point posicion, Dimension dimension, long cantidad) {
		super(titulo, posicion, dimension);
		this.cantidad = this.getCantidad();
	}

	public long getCantidad() {
		return cantidad;
	}

	public void setCantidad(long cantidad) {
		this.cantidad = (int) Math.sqrt(dimension.getWidth()*dimension.height);
	}


	@Override
	public String toString() {
		return "Agua [titulo=" + titulo + ", posicion=" + posicion + ", dimension=" + dimension + ", cantidad="
				+ cantidad + "]";
	}
	


	@Override
	public JPanel getPanel() {
		
		if(this.panelA == null) {
			JLabel l1 = new JLabel("Lago");
			JLabel l2 = new JLabel(Long.toString(cantidad));
			JLabel l3 = new JLabel("Agua");
			
			JPanel panelAgua = new JPanel();
			panelAgua.setLayout(new BorderLayout());
		
			
			panelAgua.add(l1,BorderLayout.NORTH);
			panelAgua.add(l2,BorderLayout.CENTER);
			panelAgua.add(l3,BorderLayout.SOUTH);
		
			panelAgua.setBackground(Color.CYAN);
			
			this.panelA = panelAgua;
			return (panelAgua);
		}
			return (this.panelA);
			
	}
	
}
