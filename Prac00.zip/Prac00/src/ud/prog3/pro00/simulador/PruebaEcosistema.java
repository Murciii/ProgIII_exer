package ud.prog3.pro00.simulador;

import java.awt.Dimension;
import java.awt.Point;

public class PruebaEcosistema {

	public static void main(String[] args) {
		
		Agua a1 = new Agua("Lago Titikaka", new Point(), new Dimension(),20);
		ColoniaAbejas col1 = new ColoniaAbejas("Abjeas 1", new Point(), new Dimension(), 15);
		PlantacionFlores pl1 = new PlantacionFlores("Margaritas", new Point(), new Dimension(), 30);
		
		Ecosistema.getMundo().getElementos().add(a1);
		Ecosistema.getMundo().getElementos().add(col1);
		Ecosistema.getMundo().getElementos().add(pl1);
		
		Thread hilo = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true) {
					try {
						Thread.sleep(1000);
						for (ElementoEcosistema ee :Ecosistema.getMundo().getElementos()) {
							if(ee instanceof ColoniaAbejas) {
								((ColoniaAbejas) ee).evoluciona(1);
								System.out.println(ee);
							}if(ee instanceof PlantacionFlores) {
								((PlantacionFlores) ee).evoluciona(1);
								System.out.println(ee);
							}if(ee instanceof Agua) {
								System.out.println(ee);
							}
							
						}
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}); 
		hilo.start();
	}
}
