package ud.prog3.pro00.simulador;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;



public class PlantacionFlores extends ElementoEcosistema implements Evolucionable{
	
	protected long cantidad = (int) Math.sqrt(dimension.getWidth()*dimension.height); 
	protected JPanel panelF;
	public JLabel l2 = new JLabel("",SwingConstants.CENTER);
	
	public PlantacionFlores() {
	}

	public PlantacionFlores(String titulo, Point posicion, Dimension dimension, long cantidad) {
		super(titulo, posicion, dimension);
		this.cantidad = this.getCantidad();
	}

	@Override
	public void evoluciona(int dias) {
		
		double factorCrecimiento = 0.75;
		 for (ElementoEcosistema ee : Ecosistema.getMundo().getElementos()) {
			 
			 int dist = Ecosistema.distancia( this, ee );
			 if (ee instanceof ColoniaAbejas) { // La cercan�a de abejas beneficia
				 if (dist < 500) factorCrecimiento = factorCrecimiento / dist * 500;
			 } else if (ee instanceof Agua) { // La cercan�a de agua beneficia
				 if (dist < 500) factorCrecimiento = factorCrecimiento / dist * 500;
			 }
		 }
		 cantidad = (long) (cantidad * factorCrecimiento * dias);
		 if (cantidad > 5000) cantidad = 5000;
		
	}

	public long getCantidad() {
		return cantidad;
	}

	public void setCantidad(long cantidad) {
		this.cantidad = (int) Math.sqrt(dimension.getWidth()*dimension.height);
	}

	@Override
	public String toString() {
		return "PlantacionFlores [titulo=" + titulo + ", posicion=" + posicion + ", dimension=" + dimension
				+ ", cantidad=" + cantidad + "]";
	}
	public void editarCantidad(String texto){
		this.l2.setText(texto);
	}
	public JLabel getL2() {
		return this.l2;
		
	}
	@Override
	public JPanel getPanel() {
		
		
		if(this.panelF == null) {
			JLabel l1 = new JLabel("Jardin");
			
			JLabel l3 = new JLabel("Flores");
		
			JPanel panelFlores = new JPanel();
			panelFlores.setLayout(new BorderLayout());
			
			panelFlores.add(l1,BorderLayout.NORTH);
			
			panelFlores.add(l3,BorderLayout.SOUTH);
			
			panelFlores.setBackground(Color.GREEN);
			
		 this.panelF = panelFlores;
		return (panelFlores);
		}
		return (this.panelF);
	}

}
