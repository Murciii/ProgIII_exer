package ud.prog3.pro00.simulador;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class ColoniaAbejas extends ElementoEcosistema implements Evolucionable{
	
	protected long poblacion = (int) Math.sqrt(dimension.getWidth()*dimension.height);
	protected JPanel panelAb;
	public JLabel l2 = new JLabel("",SwingConstants.CENTER);
	
	
	public ColoniaAbejas() {
		super();
	}
	
	public ColoniaAbejas(String titulo, Point posicion, Dimension dimension, long poblacion) {
		super(titulo, posicion, dimension);
		this.poblacion = this.getPoblacion();
		
	}


	public void evoluciona(int dias) {
		double factorCrecimiento = 1.0;
		 int numFlores = 0;
		 for (ElementoEcosistema ee : Ecosistema.getMundo().getElementos()) {
			 int dist = Ecosistema.distancia( this, ee );
			 if (ee instanceof ColoniaAbejas && ee!=this) { // Otra colonia de abejas perjudica
				 if (dist < 500) factorCrecimiento = factorCrecimiento * dist / 500;
			 } else if (ee instanceof PlantacionFlores) { // La cercan�a de flores beneficia
				 if (dist < 500) factorCrecimiento = factorCrecimiento / dist * 500;
				 numFlores += ((PlantacionFlores)ee).getCantidad();
			 }
		 }
		 if (numFlores < 50) factorCrecimiento *= 0.1; // Insuficientes flores mata
		 poblacion = (long) (poblacion * factorCrecimiento * dias);
		 if (poblacion > 5000) poblacion = 5000; // L�mite de poblaci�
	}

	
	public long getPoblacion() {
		return poblacion;
	}


	public void setPoblacion(long poblacion) {
		this.poblacion = (int) Math.sqrt(dimension.getWidth()*dimension.height);
	}


	@Override
	public String toString() {
		return "ColoniaAbejas [titulo=" + titulo + ", posicion=" + posicion + ", dimension=" + dimension
				+ ", poblacion=" + poblacion + "]";
	}
	
	public void editarPoblacion(String texto){
		this.l2.setText(texto);
	}
	public JLabel getL2() {
		return this.l2;
		
	}

	@Override
	public JPanel getPanel() {
		
		if(this.panelAb == null) {
			
			JLabel l1 = new JLabel("Colonia");
			
			JLabel l3 = new JLabel("Abejas");
		
			JPanel panelAbejas = new JPanel();
			panelAbejas.setLayout(new BorderLayout());
	
			panelAbejas.add(l1,BorderLayout.NORTH);
			
			panelAbejas.add(l3,BorderLayout.SOUTH);
			
			panelAbejas.setBackground(Color.YELLOW);
			
			this.panelAb = panelAbejas;
			return (panelAbejas);
			
		}
		
		return (this.panelAb);
	}


	
	
	


	
}
