package ud.prog3.pro00.simulador;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JPanel;

public abstract class ElementoEcosistema {
	
	protected String titulo;
	protected Point posicion;
	protected Dimension dimension;
	
	
	public ElementoEcosistema() {
		// TODO Auto-generated constructor stub
	}
	
	public ElementoEcosistema(String titulo, Point posicion, Dimension dimension) {
		super();
		this.titulo = titulo;
		this.posicion = posicion;
		this.dimension = dimension;
	}

	public String getTitulo() {
		return titulo;
	}
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Point getPosicion() {
		return posicion;
	}

	public void setPosicion(Point posicion) {
		this.posicion = posicion;
	}

	public Dimension getDimension() {
		return dimension;
	}

	public void setDimension(Dimension dimension) {
		this.dimension = dimension;
	}

	public  abstract JPanel getPanel();
	
}
