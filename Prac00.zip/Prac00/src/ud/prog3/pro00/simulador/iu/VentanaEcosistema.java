package ud.prog3.pro00.simulador.iu;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

import ud.prog3.pro00.simulador.Agua;
import ud.prog3.pro00.simulador.ColoniaAbejas;
import ud.prog3.pro00.simulador.Ecosistema;
import ud.prog3.pro00.simulador.ElementoEcosistema;
import ud.prog3.pro00.simulador.PlantacionFlores;


@SuppressWarnings("serial")
public class VentanaEcosistema extends JFrame{
	
	protected static boolean btVivo = false;
	
	static int coordenadaX = 0;
	static int coordenadaY = 0;
	
	
	
	public static void main(String[] args) {
	
		
		 JFrame vE = new JFrame();
		 vE.setTitle("Simulador Ecosistema");
		 vE.setSize(500,500);
		 vE.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 	 
		 
		JButton btVida = new JButton("Vida");

		
		JComboBox<String> cbElemEco = new JComboBox<String>();
		cbElemEco.addItem("Agua");
		 cbElemEco.addItem("Abejas");
		 cbElemEco.addItem("Flores");
		 
		
		 JToggleButton btMov = new JToggleButton("Mover");
		 JToggleButton btCr = new JToggleButton("Crear");

		 
		 JPanel panelS = new JPanel();
		 panelS.add(btMov, FlowLayout.LEFT);
		 panelS.add(btCr,FlowLayout.CENTER);
		 panelS.add(cbElemEco,FlowLayout.RIGHT);
		 panelS.add(btVida);
		 
		 JPanel panelC = new JPanel();
		 panelC.setLayout(null);
		 panelC.setBackground(Color.GRAY);
		 
		 
		 vE.add(panelS,BorderLayout.SOUTH);
		 vE.add(panelC,BorderLayout.CENTER);
		 
		 vE.setVisible(true);
		 
		 btVida.addActionListener(new ActionListener() {
			 
			 protected boolean estaVivo;
			@Override
			public void actionPerformed(ActionEvent e) {				
				
				
				
				Thread hilo = new Thread(new Runnable() {
					
					@Override
					public void run() {	

						estaVivo = true;

						while(estaVivo == true ) {
							
							try {	
								
								Thread.sleep(1500);
								for (ElementoEcosistema ee :Ecosistema.getMundo().getElementos()) {
									if(ee instanceof ColoniaAbejas) {
										((ColoniaAbejas) ee).evoluciona(1);
										((ColoniaAbejas) ee).editarPoblacion( Long.toString(((ColoniaAbejas) ee).getPoblacion() ));
										System.out.println(ee);
										
										panelC.revalidate();
										
									}if(ee instanceof PlantacionFlores) {
										((PlantacionFlores) ee).evoluciona(1);
										((PlantacionFlores) ee).editarCantidad(Long.toString(((PlantacionFlores) ee).getCantidad()));
										System.out.println(ee);
										
										panelC.revalidate();
										
									}
									
								}
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}	
					}
				});
				if(btVivo == true) {
					hilo.start();
					btVivo = false;
					btVida.setText("Vida");
					btMov.setEnabled(true);
					btCr.setEnabled(true);
				}else {
					btVivo = true;
					btVida.setText("Parar");
					estaVivo = false;
					btMov.setEnabled(false);
					btCr.setEnabled(false);
				}				
			}			
		});
		
		 vE.addMouseListener(new MouseListener() {
			 
			 int contadorElementos = 1;
			@Override
			public void mouseReleased(MouseEvent e) {
				
				int ancho = e.getX() - coordenadaX;
				int alto = e.getY() - coordenadaY;
				
				if(e.getX() != coordenadaX && e.getY() != coordenadaY) {
		
					if(btMov.isSelected()) {
				
						for  (ElementoEcosistema ee : Ecosistema.getMundo().getElementos()) {
							
							if( coordenadaX< (ee.getPosicion().x + ee.getDimension().width)&& coordenadaY < (ee.getPosicion().y + ee.getDimension().height) && ee.getPosicion().x < coordenadaX && ee.getPosicion().y < coordenadaY) {
								
				
								ee.setPosicion(new Point(e.getX(), e.getY()));
								ee.getPanel().setBounds(e.getX(), e.getY(), ee.getDimension().width, ee.getDimension().height);						
								panelC.revalidate();
							
							}
							
						}
					
					}
				
				}	
				if(btCr.isSelected()) {
					
					
					
					if(cbElemEco.getSelectedItem().equals("Flores")) {
							
							PlantacionFlores flores = new PlantacionFlores(" Jardin " + contadorElementos, new Point(coordenadaX,coordenadaY),new Dimension(ancho,alto),10);
							contadorElementos +=1 ;
							
							flores.getPanel().setPreferredSize(flores.getDimension());
							
							
							JPanel panelF = flores.getPanel();
							flores.editarCantidad(Long.toString(flores.getCantidad()));
							panelF.add(flores.getL2());
							panelC.add(panelF);
							
							flores.getPanel().setBounds(coordenadaX, coordenadaY, flores.getDimension().width, flores.getDimension().height);
							Ecosistema.getMundo().getElementos().add(flores);
							
							panelC.revalidate();
							
					}if(cbElemEco.getSelectedItem().equals("Abejas")) {
							
							ColoniaAbejas abejas = new ColoniaAbejas("Abejas " + contadorElementos, new Point(coordenadaX,coordenadaY), new Dimension(ancho,alto), 10);
							contadorElementos +=1 ;
							abejas.getPanel().setPreferredSize(abejas.getDimension());
							
							
							JPanel panelAb = abejas.getPanel();
							abejas.editarPoblacion(Long.toString(abejas.getPoblacion()));
							panelAb.add(abejas.getL2());
							panelC.add(panelAb);
							
							abejas.getPanel().setBounds(coordenadaX, coordenadaY, abejas.getDimension().width, abejas.getDimension().height);
							Ecosistema.getMundo().getElementos().add(abejas);
							
							panelC.revalidate();
						
					}if(cbElemEco.getSelectedItem().equals("Agua")) {
							
							Agua agua = new Agua(" Lago  " + contadorElementos, new Point(coordenadaX,coordenadaY), new Dimension(ancho,alto), 10);
							contadorElementos +=1 ;
							
							Ecosistema.getMundo().getElementos().add(agua);
							panelC.add(agua.getPanel());
							
							agua.getPanel().setBounds(coordenadaX, coordenadaY, agua.getDimension().width, agua.getDimension().height);
							
							panelC.revalidate();
							
					}
				}
		}
			@Override
			public void mousePressed(MouseEvent e) {
				
				coordenadaX = e.getX();
				coordenadaY = e.getY();

			
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});	 
	}
}
