package ud.prog3.pro00.simulador;

public interface Evolucionable{
	public void evoluciona(int dias);
}
